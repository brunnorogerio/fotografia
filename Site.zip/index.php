<?php /*
Theme Name: Brunno Rogerio Photography
Theme URI: https://brunnorogerio.com/
Author: Brunno Rogério
Author URI: https://brunnorogerio.com/
Description: Tema personalizado para portfólio de fotografia de natureza e esportes
Version: 1.0
*/ ?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php bloginfo('name'); ?> | <?php bloginfo('description'); ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;500;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
  <header>
    <h1><?php bloginfo('name'); ?></h1>
    <p><?php bloginfo('description'); ?></p>
  </header>

  <nav>
    <?php wp_nav_menu(array('theme_location' => 'menu-principal')); ?>
  </nav>

  <section class="hero">
    <h1>Explore a Natureza Através da Lente</h1>
  </section>

  <section id="projetos">
    <h2>Galeria de Fotos</h2>
    <div class="grid">
      <img src="https://source.unsplash.com/400x300/?surf" alt="Surf">
      <img src="https://source.unsplash.com/400x300/?forest" alt="Floresta">
      <img src="https://source.unsplash.com/400x300/?animal" alt="Animal">
      <img src="https://source.unsplash.com/400x300/?beach" alt="Praia">
      <img src="https://source.unsplash.com/400x300/?volleyball" alt="Vôlei">
    </div>
  </section>

  <section id="sobre">
    <h2>Sobre</h2>
    <p>Sou Brunno Rogério, apaixonado por capturar a beleza da natureza — de paisagens exuberantes a animais selvagens — além de momentos intensos no surfe, vôlei e futebol. Cada imagem é uma tentativa de eternizar aquilo que muitas vezes passa despercebido.</p>
  </section>

  <section id="contato">
    <h2>Contato</h2>
    <p>Email: brunno@example.com</p>
    <p>Instagram: <a href="https://instagram.com/seuperfil" target="_blank">@seuperfil</a></p>
  </section>

  <footer>
    <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. Todos os direitos reservados.</p>
  </footer>

  <?php wp_footer(); ?>
</body>
</html>
