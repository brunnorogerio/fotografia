<?php
function brunno_theme_setup() {
  add_theme_support('title-tag');
  register_nav_menus(array(
    'menu-principal' => __('Menu Principal')
  ));
}
add_action('after_setup_theme', 'brunno_theme_setup');
?>

